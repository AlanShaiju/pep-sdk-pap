package com.example.pep.sdk.core.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface PapAttribute {

    /** PAP attribute name. Mapped to the wire location declared in the catalog. */
    String attributeName();
}
